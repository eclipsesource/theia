# demo-plugin
demo-plugin Plugin example for Theia.
